ledtable
========

LED tables form LED stripes.

View the [Arduino libraries](arduino/libraries/).

How to build an [LED table (German)](https://www.youtube.com/watch?v=meTvfm8NTYc)