cross
=====

[This example](cross.ino) shows a cross. This can be used to determine the `pixelorder`, if unknown.

![cross.jpg](cross.jpg)