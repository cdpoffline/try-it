coderdojo
=========

[This example](coderdojo.ino) shows the CoderDojo logo. This is used to test the circle and ellipse drawing algorithm.

![coderdojo.jpg](coderdojo.jpg)