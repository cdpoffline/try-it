tron
====

[This example](tron.ino) is a four-player game, a mixture between [tron](http://www.classicgamesarcade.com/game/21670/tron-game.html), [curve fever](http://curvefever.com/) and, [snake](https://en.wikipedia.org/wiki/Snake_%28video_game%29). Each player controls a dot and can collect powerups.

![tron.jpg](tron.jpg)