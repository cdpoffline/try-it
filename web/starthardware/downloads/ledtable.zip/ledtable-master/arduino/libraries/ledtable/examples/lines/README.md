lines
=====

[This example](lines.ino) shows several lines. This can be used to test the line drawing algorithm.

![lines.jpg](lines.jpg)