hpi_logo
========

[This example](hpi_logo.ino) shows the logo of the [Hasso-Plattner-Institute](https://hpi.de) in Potsdam. It uses a `Stamp` to color the letters, requiring only three lines of code.

![hpi_logo.jpg](hpi_logo.jpg)
