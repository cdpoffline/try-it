transparency
============

[This example](transparency.ino) shows lines in black and white that are overwritten by less and less transparent pixels in different colors. This tests the computation of transparency.

![transparency.jpg](transparency.jpg)